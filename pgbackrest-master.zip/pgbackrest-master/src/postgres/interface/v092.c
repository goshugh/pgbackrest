/***********************************************************************************************************************************
PostgreSQL 9.2 Interface

See postgres/interface/version.intern.h for documentation.
***********************************************************************************************************************************/
#include "build.auto.h"

#define PG_VERSION                                                  PG_VERSION_92

#include "postgres/interface/version.intern.h"

PG_INTERFACE(092);
