/***********************************************************************************************************************************
PostgreSQL 9.6 Interface

See postgres/interface/version.intern.h for documentation.
***********************************************************************************************************************************/
#include "build.auto.h"

#define PG_VERSION                                                  PG_VERSION_96

#include "postgres/interface/version.intern.h"

PG_INTERFACE(096);
