/***********************************************************************************************************************************
PostgreSQL 10 Interface

See postgres/interface/version.intern.h for documentation.
***********************************************************************************************************************************/
#include "build.auto.h"

#define PG_VERSION                                                  PG_VERSION_10

#include "postgres/interface/version.intern.h"

PG_INTERFACE(100);
